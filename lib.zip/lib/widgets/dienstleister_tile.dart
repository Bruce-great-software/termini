import 'package:flutter/material.dart';

class DienstleisterTile extends StatelessWidget {
  final Map<String, dynamic> data;
  final VoidCallback onTap;

  /// Optional: bereits gefilterte/ passende Angebote aus der Sammlung `angebote`.
  /// Erwartetes Schema je Eintrag:
  /// { 'titel': String, 'dauer': num?, 'preis': num?, 'zielgruppe': String?, 'chipColor': Color|int? }
  final List<Map<String, dynamic>>? matchedOffers;

  const DienstleisterTile({
    super.key,
    required this.data,
    required this.onTap,
    this.matchedOffers,
  });

  // ---------------- Helper: Format ----------------
  String _fmtPreis(dynamic v) {
    if (v == null) return '';
    if (v is int) return '$v €';
    if (v is double) {
      final isWhole = v.truncateToDouble() == v;
      return isWhole ? '${v.toStringAsFixed(0)} €' : '${v.toStringAsFixed(2)} €';
    }
    return '$v €';
  }

  String _fmtDauer(dynamic v) {
    if (v == null) return '';
    if (v is int) return '$v Min.';
    if (v is double) return '${v.round()} Min.';
    return '$v Min.';
  }

  // ---------------- Helper: Farben ----------------
  static const String _zgDamen  = 'Damen';
  static const String _zgHerren = 'Herren';
  static const String _zgKinder = 'Kinder';

  Color _colorForZielgruppe(String? z) {
    switch (z) {
      case _zgDamen:
        return const Color(0xFFE91E63); // Pink
      case _zgKinder:
        return const Color(0xFFFFC107); // Gelb (Amber)
      case _zgHerren:
      default:
        return Colors.blueAccent;       // Blau
    }
  }

  /// Versucht zuerst offer['chipColor'] (Color oder int), sonst Zielgruppe, sonst Blau.
  Color _resolveChipColor(Map<String, dynamic> offer) {
    final dynamic c = offer['chipColor'];
    if (c is Color) return c;
    if (c is int) return Color(c);
    final zg = offer['zielgruppe'] as String?;
    return _colorForZielgruppe(zg);
  }

  @override
  Widget build(BuildContext context) {
    final distance = data['distance'];
    final logoUrl  = data['logoUrl'];
    final name     = (data['name'] ?? 'Kein Name').toString();
    final adresse  = (data['adresse'] ?? '').toString();
    final plz      = (data['plz'] ?? '').toString();
    final ort      = (data['ort'] ?? '').toString();

    // AppBar-Farbton bleibt für Überschrift/Label
    const Color appBarColor = Colors.blueAccent;

    // Quelle: Prop > data['matchedOffers'] > []
    final List<Map<String, dynamic>> offers =
        matchedOffers ??
            ((data['matchedOffers'] as List?)
                ?.map((e) => Map<String, dynamic>.from(e as Map))
                .toList() ??
                const <Map<String, dynamic>>[]);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header: Logo + Stammdaten
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Logo links
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: (logoUrl != null && logoUrl.toString().isNotEmpty)
                        ? Image.network(
                      logoUrl,
                      width: 60,
                      height: 60,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => Container(
                        width: 60,
                        height: 60,
                        color: Colors.grey.shade300,
                        child: const Icon(Icons.store, size: 30, color: Colors.grey),
                      ),
                    )
                        : Container(
                      width: 60,
                      height: 60,
                      color: Colors.grey.shade300,
                      child: const Icon(Icons.store, size: 30, color: Colors.grey),
                    ),
                  ),
                  const SizedBox(width: 12),

                  // Name, Adresse, Entfernung
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          [
                            if (adresse.isNotEmpty) adresse,
                            [plz, ort].where((s) => s.isNotEmpty).join(' ')
                          ]
                              .where((s) => s.toString().trim().isNotEmpty)
                              .join(', '),
                          style: const TextStyle(color: Colors.black54),
                        ),
                        if (distance is num)
                          Padding(
                            padding: const EdgeInsets.only(top: 4),
                            child: Text(
                              '${distance.toStringAsFixed(1)} km entfernt',
                              style: const TextStyle(fontSize: 12, color: Colors.grey),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),

              // -------------------- NEU: Angebote gruppiert pro Titel --------------------
              if (offers.isNotEmpty) ...[
                const SizedBox(height: 10),
                const Divider(height: 1),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Icon(Icons.local_offer, size: 18, color: appBarColor),
                    const SizedBox(width: 6),
                    Text(
                      'Passende Angebote',
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        color: appBarColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),

                // Gruppieren: title -> zielgruppe -> offer
                Builder(builder: (_) {
                  final Map<String, Map<String, Map<String, dynamic>>> grouped = {};
                  for (final o in offers) {
                    final title = (o['titel'] ?? o['name'] ?? '').toString().trim();
                    final zg = (o['zielgruppe'] ?? '').toString().trim();
                    if (title.isEmpty) continue;
                    if (!grouped.containsKey(title)) grouped[title] = {};
                    if (zg.isNotEmpty) grouped[title]![zg] = o;
                  }

                  const zielgruppenOrder = <String>[_zgDamen, _zgHerren, _zgKinder];

                  return Column(
                    children: grouped.entries.map((entry) {
                      final title = entry.key;
                      final byGroup = entry.value;

                      return Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            // Links: "Kategorie – Leistung"
                            Expanded(
                              child: Text(
                                title,
                                style: const TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 15,
                                ),
                              ),
                            ),

                            // Rechts: Zielgruppen-Segmente in einer Reihe (nur vorhandene Gruppen)
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: zielgruppenOrder
                                  .where(byGroup.containsKey)
                                  .map((zg) {
                                final o = byGroup[zg]!;
                                final color = _resolveChipColor(o);
                                final preis = _fmtPreis(o['preis']);
                                final dauer = _fmtDauer(o['dauer']);

                                const textColor = Colors.black;

                                return Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                  decoration: BoxDecoration(
                                    color: color.withOpacity(0.15), // Farbiges Badge
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: color), // Farbig umrissen
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Text(
                                        zg,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          color: textColor, // <-- jetzt schwarz
                                        ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        preis,
                                        style: const TextStyle(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          color: textColor, // <-- jetzt schwarz
                                        ),
                                      ),
                                      if (dauer.isNotEmpty) ...[
                                        const SizedBox(height: 1),
                                        Text(
                                          dauer,
                                          style: TextStyle(
                                            fontSize: 10,
                                            color: textColor.withOpacity(0.7), // leicht abgetöntes Schwarz
                                          ),
                                        ),
                                      ],
                                    ],
                                  ),
                                );
                              }).toList(),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  );
                }),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
